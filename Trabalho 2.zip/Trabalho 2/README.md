# Elderly Project

This is a project for elderly where we will make a mobile application to add photos to an album, all done with a graphical interface.
